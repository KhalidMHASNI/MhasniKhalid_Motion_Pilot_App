package com.example.mhasnikhalid_motionpilot_projet;

public class Constants {

    public static final String BROADCAST_DETECTED_ACTIVITY = "activity_intent";

    public static final long DETECTION_INTERVAL_IN_MILLISECONDS = 5000;

}